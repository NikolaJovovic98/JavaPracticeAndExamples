import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CalculatorPanel extends JPanel {

	JTextField text1;
	JTextField text2; //JTextField je polje u kome upisujemo podatke i iz koga njih citamo
	JTextField text3;
	
	JLabel label1;
	JLabel label2; //JLabel je polje koje sluzi za tekst dakle da nesto pise ne moze se dirati samo postoji
	JLabel label3;
	
	JButton button1;
	JButton button2; //JButton je polje koje sluzi da se pritiskom na njega nesto desi
	JButton button3;
	JButton button4;
	
	String greska = "Nemoguca operacija";
	
	public CalculatorPanel() {
		
		
		this.setLayout(new GridLayout(10,0)); //Ovo je izlged prozora dakle 10 polja koja idu jedno ispod drugog
		
		
		
		 label1 = new JLabel("Broj 1:");
		 label2 = new JLabel("Broj 2:");  
		 label3 = new JLabel("Rezultat:");
		
		
		text1 = new JTextField("Unesi broj");
		text1.setBackground(Color.yellow); //Postavljamo boju pozadine text1 JTextField
	
		text2 = new JTextField("Unesi broj");
		text2.setBackground(Color.yellow); 
		
		text3 = new JTextField();
		text3.setBackground(Color.green);
		
		text3.setEditable(false); //Ovo stavimo da onemogucimo pisanje po JTextField rezultat
		
		 button1 = new JButton("+");
		 button2 = new JButton("-");
		 button3 = new JButton("*");
		 button4 = new JButton("/");
		
		//Postavljamo boju pozadine dugmadi
		button1.setBackground(Color.orange);
		button2.setBackground(Color.orange);
		button3.setBackground(Color.orange);
		button4.setBackground(Color.orange);
		
		//Svakom dugmetu dodajemo posebne komande
		button1.setActionCommand("Sabiranje");
		button2.setActionCommand("Oduzimanje");
		button3.setActionCommand("Mnozenje");
		button4.setActionCommand("Dijeljenje");
		//Svakom dugmetu dodajmo listener pomocu kojeg ce reagovati na akcije
		button1.addActionListener(new CalculatorListener());
		button2.addActionListener(new CalculatorListener());
		button3.addActionListener(new CalculatorListener());
		button4.addActionListener(new CalculatorListener());
		//Tekst polju text1 i 2 dodajemo listenere kao i buttonu
		text1.addFocusListener(new TextFieldListener());
		text2.addFocusListener(new TextFieldListener());
		
		//lijepimo polja na nas prozor
		this.add(label1);
		this.add(text1);
		this.add(label2);
		this.add(text2);
		this.add(label3); 
		this.add(text3);
		
		this.add(button1);
		this.add(button2);
		this.add(button3);
		this.add(button4);
		
		
		
	
	}

	//Pravimo privatnu klasu koju nazivamo kao nas panel samo dodamo Listener i zakacimo mu interfejst zvani ActionListener
	//koji ce nam sam generisati abstraktne funkcije koje sami mijenjamo po zelji
	
	private class CalculatorListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			

			//Ukoliko pritiskom na polje sa komandom sabiranje u nasem slucaju button1 onda se desava sljedece : 
			if(e.getActionCommand().equals("Sabiranje")) {
				
				//Pomocu parseDouble uzimamo tekst tj string i pretvaramo ga u double vrijednost
				//uzimamo vrijednost iz polja text1 dakle tekst pretvaramo u broj
				double broj1 = Double.parseDouble(text1.getText());
				//uzimamo vrijednost iz polja texta 2 radimo isto kao sa text1
				double broj2 = Double.parseDouble(text2.getText());
				//sabiramo ta 2 broja jer je u pitanju sabiranje
				double zbir = broj1+broj2;
				
				//pomocu toString radimo obrnuto dakle double pretvaramo u string da bi se pokazao kao text u text3 polju
				//koje predstavlja rezultat
				
				text3.setText(Double.toString(zbir));
				
				
			}
			
			
			
	       if(e.getActionCommand().equals("Oduzimanje")) {
				
				double broj1 = Double.parseDouble(text1.getText());
				
				double broj2 = Double.parseDouble(text2.getText());
				
				double oduzimanje = broj1-broj2;
				
				text3.setText(Double.toString(oduzimanje));
				
				
			}
	       
	   	if(e.getActionCommand().equals("Mnozenje")) {
			
			double broj1 = Double.parseDouble(text1.getText());
			
			double broj2 = Double.parseDouble(text2.getText());
			
			double mnozenje = broj1*broj2;
			
			text3.setText(Double.toString(mnozenje));
			
			
		}
	   	
	  	if(e.getActionCommand().equals("Dijeljenje")) {
			
				
	  		double broj1 = Double.parseDouble(text1.getText());
			
			double broj2 = Double.parseDouble(text2.getText());
			
			if(broj2==0) {
				
			    text3.setText(greska);
				
			}
			
			else {
			
			double dijeljenje = broj1/broj2;
			
			
			
			text3.setText(Double.toString(dijeljenje));
			
			}
			}
if(e.getActionCommand().equals("Sabiranje") || e.getActionCommand().equals("Oduzimanje") ||e.getActionCommand().equals("Mnozenje") ||e.getActionCommand().equals("Dijeljenje")) {
			
    String text11 = text1.getText();
	
    String text22 = text2.getText();
    
    if(text11=="Unesi broj" || text11=="" || text22=="Unesi broj" || text22=="") {
    	
    	text3.setText(greska);
    	
    }
    
	  		
}
		}
	
	}
	
	
	private class TextFieldListener implements FocusListener{

		String recordedText; //Pravimo novi string u koji cemo ubaciti text iz JTextField 
		
		@Override
		public void focusGained(FocusEvent e) {
			
	  //Pomocu ovoga recordedText prima vrijednost onoga teksta dje smo kliknuli misem dakle e predstavlja klik misa
	  //i onda nakon klika uzimamo vrijednost i onda tu vrijednost postavljamo na " " u prevodu ostaje prazno	
			
			recordedText=((JTextField)e.getSource()).getText(); 
			((JTextField)e.getSource()).setText("");		
			
			
		}

		@Override
		public void focusLost(FocusEvent e) {
			
		//Ako je ono polje JTextField dje smo kliknuli prazno dakle " " postavljamo ga nazad na predjasnju vrijednost recordedText 
			
			if (((JTextField)e.getSource()).getText().equals("")){
				((JTextField)e.getSource()).setText(recordedText);
			}	
			
		}
		
	
	}

	

}

	

