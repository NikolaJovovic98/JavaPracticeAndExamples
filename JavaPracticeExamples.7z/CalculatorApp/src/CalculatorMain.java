import java.util.*;

import javax.swing.JFrame;


public class CalculatorMain {

	public static void main(String[] args) {
		
		JFrame calculator = new JFrame("Calculator App");
		
		CalculatorPanel calPan = new CalculatorPanel();
		
		calculator.add(calPan);
		   
		calculator.setSize(400,400);
		
		calculator.setVisible(true);
		
		calculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		calculator.setResizable(false);
		
		calculator.setLocationRelativeTo(null);
		
		
	}

}
