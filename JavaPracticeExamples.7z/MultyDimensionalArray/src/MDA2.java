import java.util.*;

public class MDA2 {

	public static void main(String[] args) {
		
		
		/*Odbrana kraljevstva
Kvadartolend je država u obliku kvadrata, podijeljena na NxN manjih kvadratića. Kralj zna koliko
vojnika patrolira u svakom dijelu kraljevstva. Sada želi saznati koliko vojnika brani granice kraljevstva.
Pomozite kralju i napišite program koji određuje broj vojnika koji patroliraju granicom kraljevstva.
Ulaz: Prvi red sadrži broj N – broj kvadratića po jednoj strani. Sljedećih N redova sadrže po N cijelih
brojeva – broj vojnika koji patroliraju u odgovarajućem kvadratiću. Izlaz: Štampati jedan cio broj – koliko
vojnika patrolira granicom.
                            */
		
		//Prvo unosimo broj N tj broj kvadratica po jednoj strani u prevodu broj redova
		//A ako imamo broj redova imamo i broj kolona jer je NxN sledeci broj koji unosimo je
		//N tj broj vojnika u kvadraticu 
		
		
		Scanner unos = new Scanner(System.in);
		
		System.out.println("Unesite broj kvadratica po jednoj strani: ");
		
		int redovi = unos.nextInt();
		
		int kolone = redovi;
		
//		System.out.println("Unesite broj vojnika koji patroliraju u odg kvadratic :");
		
	
		int[][] kraljevstvo = new int[redovi][kolone];
		
		
		for(int i = 0;i<kraljevstvo.length;i++) {
			
			for(int j=0;j<kraljevstvo.length;j++) {
				
				kraljevstvo[i][j]=unos.nextInt();
				
			}
			
		}
		
		System.out.println("Izgled kraljevstva : ");
		
		for(int i =0;i<kraljevstvo.length;i++) {
			
			for(int j =0;j<kraljevstvo.length;j++) {
				
				
				System.out.print(kraljevstvo[i][j]+" ");
				
			}
			
			System.out.println();
			
		}
		
		int brojVojnika = 0;
		
		for(int i=0;i<kraljevstvo.length;i++) {
			
			for(int j=0;j<kraljevstvo[0].length;j++) {
				
				if (i == 0 || j == 0 || i == kraljevstvo.length-1 || j == kraljevstvo[0].length-1)
				{
				
					brojVojnika = brojVojnika + kraljevstvo[i][j];
		
				}
			
			}
		
		}
		
		System.out.println("Broj vojnika na granici je :" + brojVojnika);
		

	}

}
