import java.util.*;

public class MDA {
	
	public static boolean prostBroj(int n) {
		
		boolean flag = true ;
		
		for(int i=2;i<=n/2;i++) {
			
			if(n==2 || n%i==0) {
				
				flag = false ;
				
			}
			
			
			
		}
		
		return flag;
		
		
	}
	
	public static int savrsenBroj(int n) {
		
		int sum =0;
		
		for(int i=1;i<=n/2;i++) {
			
			if(n%i==0) {
				
				sum+=i;
				
			}
			
			
		}
		
		return sum;
		
	}

	public static int sabiranjeDvaDniza(int niz[][]) {
		
		int zbir = 0;
		
		for(int i = 0 ; i < niz.length;i++) {
			
			for(int j =0;j<niz[0].length;j++) {
				
				
				zbir+=niz[i][j];
				
			}
			
		}
		
		return zbir;
		
		
	}
	
	public static void brojKolonaBrojRedova(int niz[][]) {
		
		int redovi=0;
		int kolone=0;
		
		for(int i =0;i<niz.length;i++) {
			
			for(int j = 0;j<niz[0].length;j++) {
				
				kolone++;
				
			}
			
			redovi++;
		}
		
		System.out.println("Redovi:"+redovi+" "+"Kolone:"+kolone/redovi);
	}

	public static void popunjavanjeSlucajnimBrojevima(int niz[][]) {
		
		for (int i =0;i<niz.length;i++) {
			
			for(int j =0;j<niz[i].length;j++) {
				
				
				niz[i][j]=(int) (Math.random()*10);
				
			}
			
			
		}
		
       for (int i =0;i<niz.length;i++) {
			
			for(int j =0;j<niz[i].length;j++) {
				
				
				System.out.print(niz[i][j]+" ");
				
			}
			
			System.out.println();
		}
		
	}

	public static int zbirGlavneDijagonale(int niz[][])
	{
		
		int zbirDijagonale =0;
		
	for(int i = 0,j=0; i<niz.length && j<niz.length;i++,j++) {
			
			zbirDijagonale+=niz[i][j];
       
       
	}
		
		return zbirDijagonale;
		
	}
	
	public static int zbirElemenataIspodDijagonala(int niz[][]) {

		
		
		
		  int sumBottom=0;
		  /*
           for (int i = 1; i < niz.length; i++) {
                  for (int j=i-1 ; j>=0 ; j--) {
                        sum= sum + niz[i][j];
                  }
                  
           }
               */
		  
		  for (int i = 0; i < niz.length; i++) 
		        for (int j = 0; j < niz.length; j++) { 
		            if (i > j) { 
		            	sumBottom += niz[i][j]; 
		            } 
		        } 
		  
		 
		  
		
		 return sumBottom;
		 
		
		
	}
	
	public static int zbirElemenataIznadDijagonala(int niz[][]) {
		
		int sumTop=0;
		
		
		for(int i =0;i<niz.length;i++) {
			
			for(int j=0;j<niz.length;j++) {
				
				if(i<j) {
					
					
					sumTop+=niz[i][j];
					
				}
				
				
			}
			
		}
		
		
	
		
		return sumTop;
		
		
	}
	
	public static boolean checkIfSqr(int niz[][]) {
		
		int red = 0;
		
		int kolona = 0;
		
		for(int i=0;i<niz.length;i++) {
			
			red++;
			
		}
		
		for(int j=0;j<niz[0].length;j++) {
			
			kolona++;
			
		}
		
		if(red==kolona) {
			
			return true;
			
		}
		
		else return false;
	}
	
    public static int zbirGranica(int niz[][]) {
		
		int sum = 0;
		
		
		
		for(int i=0;i<niz.length;i++) {
			
			for(int j=0;j<niz[0].length;j++) {
				
				if (i == 0 || j == 0 || i == niz.length-1 || j == niz[0].length-1)
				{
				
				sum = sum + niz[i][j];
				
				
				}
				
				
			}
			
			
		}
		
		return sum;
		
		
	}
	
	public static void sortiranjeRedova(int niz[][]) {
		
		for(int i=0;i<niz.length;i++) {
			
			for(int j=0;j<niz[0].length;j++) {
				
				for (int k = 0; k < niz[i].length - j - 1; k++) { 
                    if (niz[i][k] > niz[i][k + 1]) { 
  
                        // swapping of elements 
                        int t = niz[i][k]; 
                        niz[i][k] = niz[i][k + 1]; 
                        niz[i][k + 1] = t; 
                    } 
                } 
						
						
					}
						
				}
				
		
	
		for(int i =0;i<niz.length;i++) {
			
			for(int j=0;j<niz[0].length;j++) {
				
				System.out.print(niz[i][j]+" ");
				
				
			}
			System.out.println();
		}
		
		
		
	}
	
	public static int brojSavrsenihBrojeva(int niz[][]) {
		
		int brojac = 0;
		
		int d =0;
		
		
		
		for(int i=0;i<niz.length;i++) {
			
			for(int j=0;j<niz[0].length;j++) {
				
				if(niz[i][j]==savrsenBroj(niz[i][j])) {
					
					brojac++;
					
				}
	
			}

		}
		
		
		return brojac;
		
	}
	
	public static int brojProstihBrojeva(int niz[][]) {
		
		int brojac = 0;
		
		
		for(int i =0;i<niz.length;i++) {
			
			for(int j=0;j<niz[0].length;j++) {
				
				if(prostBroj(niz[i][j])==true) {
					
					brojac++;
					
				}
				
				
			}
			
			
		}
		
		
		return brojac;
		
		
	}
	
	public static int zbirDesneDijagonale(int niz[][]) {
		
		int zbir = 0;
		
		
		for(int i=0;i<niz.length;i++) {
			
			for(int j=0;j<niz[0].length;j++) {
				
				if((i+j)==(niz.length-1)) {
					
					zbir+=niz[i][j];
					
				}
				
				
			}
			
			
		}
		
		
		return zbir ;
		
		
	}
	
	public static int zbirObijeDijagonale(int niz[][]) {
		
		int zbir1 = zbirDesneDijagonale(niz);
		
		int zbir2 = zbirGlavneDijagonale(niz);
		
		return zbir1+zbir2;
		
		
		
		
	}
	
	public static void pozInegElementi(int niz [][]) {
		
		for(int i = 0;i<niz.length;i++) {
			
			for(int j=0;j<niz[0].length;j++) {
				
				if(niz[i][j]>0) {
					
					System.out.print(niz[i][j]+" ");
					
				}
				
				else {
					
					System.out.print(niz[i][j]+" ");
					
				}
				
			}
			
			
		}
		
		
		
		
	}
	
	public static int minimalniElement(int niz[][]) {
		
		int min = niz[0][0];
		
		for(int i=1;i<niz.length;i++) {
			
			for(int j=0;j<niz[0].length;j++) {
				
				if(min>niz[i][j]) {
					
					min=niz[i][j];
					
				}
				
				
			}
			
			
		}
		
		return min ;
		
		
	}
	
	public static void main(String[] args) {
		
		Scanner unos = new Scanner(System.in);
		
		System.out.println("Unesite broj redova :");
		
		int red = unos.nextInt();
		
		System.out.println("Unesite broj kolona :");
		
		int kolona = unos.nextInt();
		
		int[][] dvaDniz = new int[red][kolona];

		System.out.println("Unesite 2D niz : ");
		
		for(int i = 0;i<red;i++) {
			
			for(int j = 0;j<kolona;j++) {
				
				dvaDniz[i][j]=unos.nextInt();
				
			}
			
		}
		
       for(int i = 0;i<red;i++) {
			
			for(int j = 0;j<kolona;j++) {
				
				System.out.print(dvaDniz[i][j]+" ");
				
			}
			System.out.println();
		}
		
       //System.out.println(sabiranjeDvaDniza(dvaDniz));
       
      // brojKolonaBrojRedova(dvaDniz);
       
     //  System.out.println();
       
      //popunjavanjeSlucajnimBrojevima(dvaDniz);
      
     //System.out.println(zbirGlavneDijagonale(dvaDniz));
       
      // Zbir elemenata ispod (iznad) glavne
      // (sporedne) dijagonale. 
      
     //  System.out.println(zbirElemenataIspodDijagonala(dvaDniz))
       
     //  System.out.println(zbirElemenataIznadDijagonala(dvaDniz));
      
      // System.out.println(checkIfSqr(dvaDniz));
       
       
     //  System.out.println(zbirGranica(dvaDniz));
       
      
     // sortiranjeRedova(dvaDniz);
       
   // System.out.println(brojSavrsenihBrojeva(dvaDniz));
       
      // System.out.println(brojProstihBrojeva(dvaDniz));
     
       
       
      // System.out.println(zbirDesneDijagonale(dvaDniz));
       
     //  System.out.println(zbirObijeDijagonale(dvaDniz));
       
   //    pozInegElementi(dvaDniz);
       
       
     //  System.out.println(minimalniElement(dvaDniz));
      

       
       
       
       
       
	}
}
