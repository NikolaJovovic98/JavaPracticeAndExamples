import java.util.*;
public class MDA4 {

	public static void main(String[] args) {
	
		 Scanner unos = new Scanner(System.in);
			
			System.out.println("Unesite broj redova :");
			
			int red = unos.nextInt();
			
			System.out.println("Unesite broj kolona :");
			
			int kolona = unos.nextInt();
			
			int[][] niz = new int[red][kolona];

			System.out.println("Unesite 2D niz : ");
			
			for(int i = 0;i<red;i++) {
				
				for(int j = 0;j<kolona;j++) {
					
					niz[i][j]=unos.nextInt();
					
				}
				
			}
		
	         
	 		
	 		System.out.println("Unesite broj redova :");
	 		
	 		int red1 = unos.nextInt();
	 		
	 		System.out.println("Unesite broj kolona :");
	 		
	 		int kolona1 = unos.nextInt();
	 		
	 		int[][] niz2 = new int[red1][kolona1];

	 		System.out.println("Unesite 2D niz : ");
	 		
	 		for(int i = 0;i<red1;i++) {
	 			
	 			for(int j = 0;j<kolona1;j++) {
	 				
	 				niz2[i][j]=unos.nextInt();
	 				
	 			}
	 			
	 		}
	 		
	 		System.out.println("Prva matrica :");
	         for(int i = 0;i<red;i++) {
				
				for(int j = 0;j<kolona;j++) {
					
					System.out.print(niz[i][j]+" ");
					
				}
				System.out.println();
	         }
	          
	 		System.out.println("Druga matrica :");
	          for(int i = 0;i<red1;i++) {
	 			
	 			for(int j = 0;j<kolona1;j++) {
	 				
	 				System.out.print(niz2[i][j]+" ");
	 				
	 			}
	 			System.out.println();
	          }
	          
	          int zbirMatrica =0;
	          
	          for(int i=0;i<niz.length;i++) {
	        	  
	        	  for(int j=0;j<niz.length;j++) {
	        		  
	        		  zbirMatrica+=niz[i][j]+niz2[i][j];
	        		  
	        	  }
	        	  
	        	  
	          }
	          
	          int proizvodMatrica = 1;
		
              for(int i=0;i<niz.length;i++) {
	        	  
	        	  for(int j=0;j<niz.length;j++) {
	        		  
	        		  proizvodMatrica*=niz[i][j]*niz2[i][j];
	        		  
	        	  }
	        	  
	        	  
	          }
              
              int[][] niz3 = new int[red][kolona];
              
              for(int i=0;i<niz.length;i++) {
            	  
            	  for(int j =0;j<niz.length;j++) {
            		  
            		  niz3[i][j]=niz[i][j]+niz2[i][j];
            		  
            		  
            	  }
            	  
            	  
              }
              
              System.out.println("Novi niz :");
              
            for(int i=0;i<niz.length;i++) {
            	  
            	  for(int j =0;j<niz.length;j++) {
            		  
            		  
            		  System.out.print(niz3[i][j]+" ");
            		  
            	  }
            	  
            	  System.out.println();
              
              } 
              
              
              
		System.out.println("Zbir matrica :"+zbirMatrica);
        System.out.println("Proizvod matrica :"+proizvodMatrica);
	}

}
