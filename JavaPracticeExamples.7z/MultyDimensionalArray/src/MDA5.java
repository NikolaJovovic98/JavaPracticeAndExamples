import java.util.*;


public class MDA5 {

	public static int reverseNumber(int n) {
		
		int cifra = 0 ;
		
		int reverse = 0 ;
		
		while(n!=0) {
			
			cifra = n%10;
			
			reverse = reverse * 10 + cifra ;
			
			n = n /10;
			
			
		}
		
		
		return reverse;
		
	}
	
	public static int makeNumberEvenElements(int n) {
		
		int cifra = 0;
		
		int evenNumber = 0;
		
		while(n!=0) {
			
			cifra = n%10;
			
			if(cifra%2==0) {
				
				evenNumber = evenNumber * 10 + cifra ;
				
			}
			
			n=n/10;
			
		}
		
		
	return reverseNumber(evenNumber);	
		
	}
	
	public static int zbirKvadrataCifaraBroja(int n) {
		
		int zbir = 0 ;
		
		int cifra = 0;
		
		while(n!=0) {
			
			cifra = n % 10;
			
			zbir = zbir + cifra*cifra ;
			
			n = n / 10;
			
			
		}
		
		return zbir;
		
	}
	
	public static boolean isNumberOdd(int n) {
		
		boolean flag = true ;
		
		if(n%2==0) {
			
			flag=false;
			
		}
		
		return flag;
		
	}
	
	public static int numberOfOddNumbersInArray(int[] red) {
		
		
		int count = 0 ;
		
		for(int i = 0;i<red.length;i++) {
			
			if(isNumberOdd(red[i])) {
				
				count++;
				
			}
			
			
			
		}
		
		return count;
		
	}
	
	public static boolean divisibleBySeven(int n) {
		
	     if(n%7==0) {
	    	 
	    	 return true ;
	    	 
	     }
		
	     else return false ;
	}
	
	public static int numberOfEvenElementsDivisibleBySeven(int[] red) {
		
		int count = 0 ;
		
		for(int i = 0;i<red.length;i++) {
			
			if(divisibleBySeven(makeNumberEvenElements(red[i])))
				
				count++;
			
			
		}
		
		return count;
		
		
	}
	
	public static void MatrixElementsEvenWithSeven(int[][] matrix) {
		
		int[] count =  new int[matrix.length];
		
		for(int i=0;i<matrix.length;i++) {
			
			count[i]=numberOfEvenElementsDivisibleBySeven(matrix[i]);
			
			
		}
		
		
		for(int i = 0 ;i<matrix.length;i++) {
			
			if(count[i]>=2) {
				
				System.out.println(i);
				
			}
			
			
		}
		
		
		
	}
	
	public static void MatrixOddElements(int[][] matrix) {
		

		int[] sol = new int[matrix.length];
		for(int i = 0; i<matrix.length; i++) {
			sol[i] = numberOfOddNumbersInArray(matrix[i]);
		}
		for(int i = 0; i<matrix.length; i++) {
			if(sol[i]>=2) {
				System.out.println(i);
			}
		}
		
	}
	
	public static int zbirKvadrataElemenataDivisibleSaSedam(int[] red) {
		
		int count  = 0;
		
		for(int i = 0 ; i <red.length;i++) {
			
			if(divisibleBySeven(zbirKvadrataCifaraBroja(red[i]))) {
				
				count ++;
				
			}
			
			
		}
		
		return count ;
		
	}
	
	public static void MatrixPowTwoElementsDivisbleBySeven(int[][] matrix) {
		
		int[] red = new int [matrix.length];
		
		
		for(int i = 0 ; i <matrix.length;i++) {
			
			red[i] = zbirKvadrataElemenataDivisibleSaSedam(matrix[i]);
			
			
			
		}
		for(int i = 0 ; i <matrix.length;i++) {
			
		if(red[i]>=2) {
			
			
			System.out.println(i);
			
			
		}
			
			
		}
		
		
		
	}
	
	public static void main(String[] args) {

//      Data je matrica nxn cijelih brojeva stampati redne brojeve svih redova matrice koje sadrze bar 2 super broja
//      Cio broj n je super ako je a) zbir kvadrata cifara broja n je djeljiv sa 7
//b) broj koji se dobije izbacivanjem neparnih cifara iz broja |n| je djeljiv sa 7

		
		 
		int[][] matrica = {{1432,7278,154,331},
		                   {32,342,342,834},
		                  {96,132,288,61},
		                 {14,2,15,1}};
		
		//MatrixElementsEvenWithSeven(matrica);
/*
		int [][] p = {{1234, 12, -123, 541},
				  {1, 23, 345, 4567},
				  {-1234, -5412, -45678, 9010}};
		
		MatrixPowTwoElementsDivisbleBySeven(p);
		
		*/
		
		/*
	  Scanner unos = new Scanner(System.in);
	  
	  System.out.println("Unesite broj redova matrice : ");
		
	  int red = unos.nextInt();
	  
	  int kolona = red;
	  
	  int[][] matrica = new int[red][kolona];
		
	  System.out.println("Unesite matricu");
	  
	  for(int i = 0; i <matrica.length;i++) {
		  
		  for(int j = 0;j<matrica.length;j++) {
			  
			  matrica[i][j] = unos.nextInt();
		  }
		  
		  
	  }
	  */

		//stampati sve redove koji imaju barem 2 neparna broja
		/*
		int[][] matrica = {{1,2,2,4},
				           {5,8,8,8},
				           {9,10,11,12},
				           {14,13,15,16}};
		
		 for(int i = 0;i<matrica.length;i++) {
				
				for(int j = 0;j<matrica.length;j++) {
					
					System.out.print(matrica[i][j]+" ");
					
				}
				System.out.println();
	         }
		
		MatrixOddElements(matrica);
		
		*/
	
		
	}

}
