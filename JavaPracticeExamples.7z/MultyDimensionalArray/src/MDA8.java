import java.util.*;



public class MDA8 {

	
	public static void printtwoDarray(int[][] matrix) {
		

        for(int i = 0 ; i < matrix.length ; i ++) {
      	  
      	  for(int j = 0 ; j <matrix[0].length;j++) {
      		  
      		
      		System.out.print(matrix[i][j]+" ");
      		  
      	  }
      	  System.out.println();
        }
	}
	
	public static void raise(int[][] matrix) {
		
		 for(int i = 1 ; i < matrix.length ; i +=2) {
       	  
       	  for(int j = 0 ; j <matrix[0].length;j++) {
       		  
       		  
       		  matrix[i][j]+=1;
       		  
       	  }
       	  

}
	}
	
	public static void rowsReverse(int[][] matrix) {
		
		int redovi = matrix.length;
		
		int kolone = matrix[0].length;
		
		int[][] reverse = new int[redovi][kolone];
		
		  for (int i = redovi - 1; i >= 0; i--) {
	            for (int j = kolone - 1; j >= 0; j--) {
	            	
	            	
		reverse[i][kolone - 1 - j] = matrix[i][j];
		
		
	            }
	            
		  }
		  
		  printtwoDarray(reverse);
		  
		
	}
	
	public static void main(String[] args) {
		
		
	//Manipulisanje redovima matrice treba svaki drugi red obrnuti redosljed tj reverse
		
		int[][] matrix = {{1,1,6,3},
		                  {1,4,2,5},
		                  {2,0,8,6},
		                  {4,1,6,7}};
		
  
    rowsReverse(matrix);
          
        //raise(matrix);
        

  
		/*
          for(int i = 0 ; i < matrix.length ; i ++) {
        	  
        	  for(int j = 0 ; j <matrix[0].length;j++) {
        		  
        		
        		System.out.print(matrix[i][j]+" ");
        		  
        	  }
        	  System.out.println();
          }
          */
	}

}
