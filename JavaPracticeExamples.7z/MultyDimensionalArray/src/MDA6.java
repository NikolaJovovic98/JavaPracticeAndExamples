import java.util.*;


public class MDA6 {

	public static boolean prostBroj(int n) {
		
		
		boolean flag = true ;
		
		if(n==2) {
			
			return flag ;
			
		}
		
		for(int i = 2 ; i <n/2;i++) {
			
			if(n%i==0) {
				
				flag = false ;
				
			}
			
		}
		
		
		return flag;
		
	}
	
	public static int prostBrojuNizu(int[] kolona) {
		
		int brojac = 0 ;
		
		for(int i = 0 ; i <kolona.length;i++) {
			
			if(prostBroj(kolona[i])) {
				
				brojac++;
				
			}
			
			
		}
		
		return brojac;
		
	}
	
	public static void prostBrojKolonaMatrica(int[][] matrix) {
		
		int brojac = 0 ;
		
		int[] kolProst = new int[matrix[0].length];
		
		for(int i = 0 ; i<matrix[0].length;i++) {
			
			
			kolProst[i] = prostBrojuNizu(matrix[i]);
			
			
		}
		
		for(int i = 0 ; i<matrix[0].length;i++) {
			
			
			if(kolProst[i]>=1) {
				
				System.out.println(i);
				
			}
			
			
		}
				
				
		
		
	}
	
	public static void stampaPozicijeProstihBrojeva(int[][] matrix) {
		
		
		for(int i = 0 ; i<matrix.length;i++) {
			
			for(int j = 0 ; j<matrix.length;j++) {
				
				if(prostBroj(matrix[i][j])) {
					
					System.out.println("Pozicija:"+"["+i+"]"+"["+j+"]");
					
				}
				
			}
			
			
		}
		
		
		
		
		
	}
	
	public static int zbirElemenataSredineMatrice(int[][] matrix) {
		
		int zbirSpolja = 0 ;
		
		int zbirSvega = 0 ;
		
for(int i = 0 ; i < matrix.length; i++) {
			
			for(int j = 0 ; j<matrix[0].length;j++) {
				
				zbirSvega+=matrix[i][j];
				
				
			}
			}
		
		for(int i = 0 ; i < matrix.length; i++) {
			
			for(int j = 0 ; j<matrix[0].length;j++) {
				
				
				if(i==0 || j==0 || i==matrix.length-1 || j==matrix.length-1) {
					
					zbirSpolja+=matrix[i][j];
					
				}
				
				
				
			}
			
			
		}
		
		return zbirSvega-zbirSpolja;
		
		
		
	}
	
	public static int zbirGlavneDijagonale(int[][] matrix) {
		
		int zbir = 0 ;
		
		for(int i = 0 ; i<matrix.length;i++) {
			
			for(int j = 0 ; j<matrix[0].length;j++) {
				
				if(i==j) {
					
					zbir+=matrix[i][j];
					
					
				}
				
				
			}
			
			
		}
		
		
		return zbir;
		
		
	}
	
	public static int zbirSporedneDijagonale(int[][] matrix) {
		
		int zbir = 0 ;
		
		
		for(int i = 0 ; i <matrix.length;i++) {
			
			for(int j = 0 ; j <matrix[0].length;j++) {
				
				if((i+j)==matrix.length-1) {
					
					zbir+=matrix[i][j];
					
				}
				
				
			}
			
		}
		
		return zbir;
		
		
	}
	
	public static int zbirGornjegTrougla(int[][] matrix) {
		
		int zbir = 0 ;
		
	for(int i = 0 ; i <matrix.length;i++) {
			
			for(int j = 0 ; j <matrix[0].length;j++) {
				
				if(i<j) {
					
					zbir+=matrix[i][j];
					
				}
				
				
			}
			
		}
		
		
		return zbir ;
		
		
	}

	public static int zbirDonjegTrougla(int[][] matrix) {
		
		int zbir = 0 ;
		
		for(int i = 0 ; i <matrix.length;i++) {
				
				for(int j = 0 ; j <matrix[0].length;j++) {
					
					if(i>j) {
						
						zbir+=matrix[i][j];
						
					}
					
					
				}
				
			}
			
			
			return zbir ;
			
		
		
		
	}
		
	public static boolean daLiJeMatricaSimetricna(int[][] matrix) {
		
		boolean flag = true ;
		
		
		
		int size = 0 ;
		
		for(int i = 0 ; i <matrix.length;i++) {
				
				for(int j = 0 ; j <matrix[0].length;j++) {
					
					if(i<j) {
						
						size++;
						
					}
					
					
				}
				
			}
			
			
			int[] gornjiNiz = new int[size];
		
			int n = 0;
			
           for(int i = 0 ; i <matrix.length;i++) {
				
				for(int j = 0 ; j <matrix[0].length;j++) {
					
					if(i<j) {
						
						gornjiNiz[n]=matrix[i][j];
						n++;
						
					}
					
					
				}
				
			}
			
           
   		
   		for(int i = 0 ; i <matrix.length;i++) {
   				
   				for(int j = 0 ; j <matrix[0].length;j++) {
   					
   					if(i>j) {
   						
   						size++;
   						
   					}
   					
   					
   				}
   				
   			}
   			
   			
   			int[] donjiNiz = new int[size];
   		
   			int z = 0;
   			
              for(int i = 0 ; i <matrix.length;i++) {
   				
   				for(int j = 0 ; j <matrix[0].length;j++) {
   					
   					if(i>j) {
   						
   						donjiNiz[z]=matrix[i][j];
   						z++;
   						
   					}
   					
   					
   				}
   				
   			}
   		
   	for(int i = 0 ; i < gornjiNiz.length;i++) {
   		
   		
   		if(gornjiNiz[i]!=donjiNiz[i]) {
   			
   			flag = false ;
   			
   		}
   		
   		
   		
   		
   		
   		
   	}
   		
		
		
		return flag;
	}
	
	public static void main(String[] args) {

		//Provjeriti u kojem redu se nalazi prost broj
		
		int[][] matrix = {{10,11,12,13},
				          {11,10,14,15},
				          {12,13,10,16},
				          {14,15,16,10}};
		
		
		
		//prostBrojKolonaMatrica(matrix);
		
		//stampaPozicijeProstihBrojeva(matrix);
		
		//System.out.println(zbirElemenataSredineMatrice(matrix));
		
		//System.out.println(zbirGlavneDijagonale(matrix));
		
		//System.out.println(zbirSporedneDijagonale(matrix));
		
		//System.out.println(zbirGornjegTrougla(matrix));
		
		//System.out.println(zbirDonjegTrougla(matrix));
		
		//System.out.println(daLiJeMatricaSimetricna(matrix));
		
	}

}
