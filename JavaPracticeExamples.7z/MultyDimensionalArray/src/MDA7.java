import java.util.*;

public class MDA7 {


	
	public static void main(String[] args) {

		//Napraviti matricu kao npr
		
		/*
		 ova matrica se dobija kao ulaz 4 6
		 
		 0 1 2 3 4 5
         11 10 9 8 7 6
         12 13 14 15 16 17
         23 22 21 20 19 18
		
		ova se dobija kao ulaz 3 3
		
		0 1 2
		3 4 5
		6 7 8
		
		
		
		*/
		
		Scanner unos = new Scanner(System.in);
		
		System.out.println("Unesite broj redova :");
		
		int red = unos.nextInt();
		
		System.out.println("Unesite broj kolona :");
		
		int kolona = unos.nextInt();
		
		int[][] matrix = new int[red][kolona];
		
		int n = 0;
		
		for(int i = 0 ; i < matrix.length ; i ++) {
			
			for(int j = 0 ; j < matrix[0].length ; j++) {
				
                 matrix[i][j] = n ;
                 
                 n++;
			      
				
			}
			
			
			
		}
		
		
		
		
		
		
		

		for(int i = 0 ; i < matrix.length ; i ++) {
			
			for(int j = 0 ; j < matrix[0].length ; j++) {
				
				     System.out.print(matrix[i][j]+" ");
				
				
			}
			
			System.out.println();
			
		}
		
		
	}

}
