import java.util.*;

public class MDA3 {

	public static void main(String[] args) {

		//Provjeriti da li je data kvadratna matrica simetrična u odnosu na glavnu dijagonalu. Ulaz: Prvi red sadrži broj
		//N – dimenziju matrice (1 ≤ N ≤ 100). U sljedećih N redova unosi se po N brojeva – elementi matrice. Izlaz:
		//	Štampati simetricno ! ili nije simetricno !,
		
        Scanner unos = new Scanner(System.in);
		
		System.out.println("Unesite broj redova :");
		
		int red = unos.nextInt();
		
		System.out.println("Unesite broj kolona :");
		
		int kolona = unos.nextInt();
		
		int[][] niz = new int[red][kolona];

		System.out.println("Unesite 2D niz : ");
		
		for(int i = 0;i<red;i++) {
			
			for(int j = 0;j<kolona;j++) {
				
				niz[i][j]=unos.nextInt();
				
			}
			
		}
		
         for(int i = 0;i<red;i++) {
			
			for(int j = 0;j<kolona;j++) {
				
				System.out.print(niz[i][j]+" ");
				
			}
			System.out.println();
         }
         
         int size1 = 0;
         
		for(int i=0;i<niz.length;i++) {
			
			for(int j=0;j<niz.length;j++) {
				
				if(i>j) {
					
					size1++;
					
				}
				
				
			}
			
			
		}
		int[] nizLower = new int[size1];
		
		int n=0;
		
	    for(int i=0;i<niz.length;i++) {
			
			for(int j=0;j<niz.length;j++) {
				
				if(i>j) {
					
					nizLower[n]=niz[i][j];
					n++;
					
				}
				
				
			}
			
			
		}
		
		
	
	    int size2 = 0;
        
	  		for(int i=0;i<niz.length;i++) {
	  			
	  			for(int j=0;j<niz.length;j++) {
	  				
	  				if(i<j) {
	  					
	  					size2++;
	  					
	  				}
	  				
	  				
	  			}
	  			
	  			
	  		}
	  		int[] nizUp = new int[size2];
	  		
	  		int z=0;
	  		
	  	    for(int i=0;i<niz.length;i++) {
	  			
	  			for(int j=0;j<niz.length;j++) {
	  				
	  				if(i<j) {
	  					
	  					nizUp[z]=niz[i][j];
	  					z++;
	  					
	  				}
	  				
	  				
	  			}
	  			
	  			
	  		}
	  	    
	  	 
	  	    
	  	    int flag =0;
	  		
	  	    for(int i=0;i<size1;i++) {
	  	    	
	  	    	if(nizLower[i]!=nizUp[i]) {
	  	    		
	  	    		flag++;
	  	    	}
	  	    	
	  	    	
	  	    }
	  	    
	  	    if(flag>0)
	  	    {
	  	    	
	  	    	System.out.println("Nije simetricno!");
	  	    	
	  	    }
	  	    else {
	  	    	
	  	    	System.out.println("Simetricno !");
	  	    }
		
	}

}
