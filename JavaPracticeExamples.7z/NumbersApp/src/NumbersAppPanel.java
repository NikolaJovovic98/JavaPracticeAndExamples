import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Arrays;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class NumbersAppPanel extends JPanel{
	
	JLabel label1 ;
    
	JTextField text1;
	JTextField text2;
	
	JButton button1;
	JButton button2;
	JButton button3;
	
	
	public NumbersAppPanel() {
		
		this.setLayout(new GridLayout(6,0));
		
		label1 = new JLabel("Broj:");
		
		//label1.setName("Unesite broj :");
		
		text1 = new JTextField();
		text1.setBackground(Color.yellow);
		
		Font font1 = new Font("Baskerville", Font.BOLD, 20);
		
		text2 = new JTextField();
		text2.setEditable(false);
		text2.setBackground(Color.green);
		text2.setHorizontalAlignment(JTextField.CENTER);
		text2.setFont(font1);;
		
		text1.addFocusListener(new TextFieldListener());
		
		
		button1 = new JButton("Faktorijel broja");
		button2 = new JButton("Da li je broj prost ?");
		button3 = new JButton("Fibonacci-jev niz do broja");
		
		button1.setActionCommand("Fakt");
		button2.setActionCommand("Prost");
		button3.setActionCommand("Fibo");
		
		
		button1.addActionListener(new ButtonListener());
		button2.addActionListener(new ButtonListener());
		button3.addActionListener(new ButtonListener());
		
		
		this.add(label1);
		this.add(text1);
		this.add(button1);
		this.add(button2);
		this.add(button3);
		this.add(text2);
		
	}
	
private class ButtonListener implements ActionListener
{

	@Override
	public void actionPerformed(ActionEvent click) {
		
		if(click.getActionCommand().equals("Fakt")) {
			
			int broj = Integer.parseInt(text1.getText());
			
			int zbir = 1 ;
			
			for(int i = 1; i <= broj ; i ++) {
				
				zbir*=i;
				
			}
			
			text2.setText(Integer.toString(zbir));
			
			
		}
		
		if(click.getActionCommand().equals("Prost")) {
			
			boolean flag = true;
			
			int broj = Integer.parseInt(text1.getText());
			
			if(broj==2) {
				
				text2.setText("Broj je prost !");
				
			}
			
			for(int i = 2; i <= broj/2;i++) {
				
				if(broj%i==0) {
					
					flag = false ;
					
				}
				
				
			}
			
			if(flag==false) {
				
				text2.setText("Broj nije prost !");
				
			}
			else text2.setText("Broj je prost !");
			
			
		}
		
		if(click.getActionCommand().equals("Fibo")) {
			
			int broj = Integer.parseInt(text1.getText());
			
			int[] array = new int[broj];
			
			int f1 = 0;
			int f2 = 1;
			
			int next = 0 ;
			int temp = 0 ;
			
			array[0]=f1;
			array[1]=f2;
			
			for(int i = 2 ; i  <array.length ; i ++) {
				
				next = f1 + f2;
                
				array[i]=next;
				
				f1 = f2 ;
				f2 = next ;
				
				
			}
			
			text2.setText(Arrays.toString(array) );
		}
		
		
	}
	

}
	
private class TextFieldListener implements FocusListener{

	String recordedText;
	
	@Override
	public void focusGained(FocusEvent click) {
		
		recordedText=((JTextField)click.getSource()).getText(); 
		((JTextField)click.getSource()).setText("");		
		
		
		
	}

	@Override
	public void focusLost(FocusEvent click) {
		
		
		if (((JTextField)click.getSource()).getText().equals("")){
			((JTextField)click.getSource()).setText(recordedText);
		}	
	}
	
	
	
	
	
	
	
	
}


}
