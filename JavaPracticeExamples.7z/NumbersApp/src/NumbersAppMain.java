import java.util.*;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class NumbersAppMain {

	public static void main(String[] args) {
		
		JFrame prozor = new JFrame("Number App");
		
		NumbersAppPanel numPan = new NumbersAppPanel();
		
		prozor.add(numPan);
		prozor.setSize(300,300);
		prozor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		prozor.setVisible(true);
		prozor.setResizable(false);
        prozor.setLocationRelativeTo(null);
    
	}

}
