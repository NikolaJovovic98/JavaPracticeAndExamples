import java.util.*;

public class Pyramid {

	public static void reverse(int[] array) {
		
		int[] reverse = new int[array.length];
		
		int n = 0 ;
		
		for(int i = array.length-1;i>=0;i--) {
			
			reverse[n]=array[i];
			
			n++;
		}
		
		for(int i = 0 ; i<reverse.length;i++) {
			
			System.out.print(reverse[i]+" ");
			
		}
	}
	
	
	public static void main(String[] args) {
		
		//1
		//1 2
		//1 2 3
		//1 2 3 4
		//1 2 3 4 5
		/*
		Scanner unos = new Scanner(System.in);
		
		int n = unos.nextInt();
		
		for (int i = 1 ; i<=n; i++) {
			
			for(int j = 1 ; j<=i ; j++) {
				
				System.out.print(j+" ");
				
			}
			
			System.out.println();
		}
		
		*/
		
		//1 2 3 4 5
		//1 2 3 4
		//1 2 3
		//1 2
		//1
		/*
		Scanner unos = new Scanner(System.in);
		
		int n = unos.nextInt();
		
		for(int i = n ; i >0 ;i--) {
			
			for(int j = 1 ;j <=i;j++) {
				
				System.out.print(j+" ");
				
				
			}
			
			System.out.println();
		}
		*/
		
		//5 4 3 2 1
		//5 4 3 2
		//5 4 3
		//5 4
		//5
		/*
		Scanner unos = new Scanner(System.in);
		
		int n = unos.nextInt();
		
		for(int i = 1 ; i<=n ; i++) {
			
			for(int j = n ; j>=i ;j --) {
				
				
				System.out.print(j+" ");
				
			}
			
			System.out.println();
			
		}
        */
		
		//5
		//5 4
		//5 4 3 
		//5 4 3 2
		//5 4 3 2 1
		
		/*
		Scanner unos = new Scanner(System.in);
		
		int n = unos.nextInt();
		
		
		for(int i = n ; i > 0 ; i --) {
			
			for(int j = n ; j >=i ; j--) {
				
				System.out.print(j+" ");
				
				
			}
			System.out.println();
		}
		*/
		
		
		//1
		//1 2 
		//1 2 3
		//1 2 3 4
		//1 2 3 4 5
		//1 2 3 4
		//1 2 3
		//1 2
		//1
		/*
		Scanner unos = new Scanner(System.in);
		
		int n = unos.nextInt();
		
		for(int i = 1 ; i <= n ; i++) {
			
			for(int j = 1 ; j<=i;j++) {
				
				System.out.print(j+" ");
				
			}
			
			System.out.println();
		}
		
		for(int i = n-1 ; i > 0 ; i--) {
			
			for(int j = 1 ; j <=i ; j++) {
				
				System.out.print(j+" ");
				
			}
			
			System.out.println();
		}
		*/
		
		//1 2 3 4 5
		//1 2 3 4
		//1 2 3
		//1 2
		//1 
		//1 2 
		//1 2 3 
		//1 2 3 4
		//1 2 3 4 5
		/*
		Scanner unos = new Scanner(System.in);
		
		int n = unos.nextInt();
		
		
		for(int i = n ; i > 0 ; i--) {
			
			for(int j = 1 ; j <= i ;j++) {
				
				
				System.out.print(j+" ");
				
			}
			
			System.out.println();
		}
		
		for(int i = 2;i<=n;i++) {
			
			for(int j = 1;j<=i;j++) {
				
				System.out.print(j+" ");
				
				
				
			}
			System.out.println();
		}
		
		*/
		
		/*
		5 4 3 2 1
		5 4 3 2
		5 4 3
		5 4
		5
		5 4
		5 4 3
		5 4 3 2
		5 4 3 2 1
		*/
		/*
		Scanner unos = new Scanner(System.in);
		
		int n = unos.nextInt();
		
		for(int i = 1 ; i <=n ; i++) {
			
			for(int j = n ; j >=i;j--) {
				
				System.out.print(j+" ");
				
			}
			
			System.out.println();
		}
		
		for(int i = n - 1 ; i>0;i--) {
			
			for(int j = n ; j>=i;j--) {
				
				System.out.print(j+" ");
				
			}
			System.out.println();
		}
		*/
		
		/*
		5
		4 5 
		3 4 5
		2 3 4 5
		1 2 3 4 5
		*/
		
		/*
		Scanner unos = new Scanner(System.in);
		
		int n = unos.nextInt();
		for(int i=n;i>0;i--) {
			for(int j=i;j<=n;j++)
				System.out.print(j+" ");
			System.out.println();
		}
		
		*/
		
		//1
		//2 3
		//4 5 6
		//7 8 9 10
		
		/*
		
		Scanner unos = new Scanner(System.in);
		
		int n = unos.nextInt();
		
		int num = 1 ;
		
		for(int i = 1 ; i <= n ; i++ ) {
			
			for(int j = 1; j <= i ;j++) {
				
				System.out.print(num+" ");
				num++;
			}
			System.out.println();
		}
		
		*/
		
		/*
		5
		5 4
		5 4 3
		5 4 3 2
		5 4 3 2 1
		5 4 3 2
		5 4 3
		5 4
		5
		*/
		/*
		Scanner unos = new Scanner(System.in);
		
		int n = unos.nextInt();
		
		for(int i = n ; i >0 ;i--) {
			
			for(int j = n ; j >= i ;j --) {
				
				
				System.out.print(j+" ");
			}
			
			System.out.println();
			
			
		}
		
		for(int i =2 ; i <= n ;i++) {
			
			for(int j = n ;j>=i ;j--) {
				
				System.out.print(j+" ");
				
			}
			
			System.out.println();
		}
		*/
		
		
		int[] array = {5,6,3,2,7,8,3};
		
		reverse(array);
	}

}
