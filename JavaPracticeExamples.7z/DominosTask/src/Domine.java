import java.util.Scanner;

public class Domine {

	

public static int segment(int n) {
			
			int scr= 0;
			
			for(int i=0;i<=n;i++) {
				
				
				scr+=(n*2)-i;
				
			}
			
			return scr;
			
		}
	
	
	public static void main(String[] args) {
		
		/*Dominoes are played with rectangular tiles, such that they are on each tile
two labels. Each label consists of a certain number of dots. The number of dots depends on
the size of a set of dominoes. In a set of dominoes of size N, the number of dots on one tile can be
any number between 0 and N, inclusive. There are no two tiles completely in one set
of equal marks, regardless of the order of the marks on the plate. In a complete set of size N
there are all possible tiles marked 0 to N. Eg. complete set of dominoes of size 2
contains six tiles with the following labels:
Write a program that will determine the total number of dots on all tiles in full
a set of dominoes of size N. Your program should load one natural number N (1 ≤ N ≤ 1000)
- the size of a complete set of dominoes. The program should print the total number of dots on all
tiles in a complete set of dominoes of size N.

*/
		
      Scanner in= new Scanner(System.in);
		
		System.out.println("Enter a number :");
		
		int n = in.nextInt();
		
		int dominos= 0;
		
		for(int i =1;i<=n;i++) {
			
			
			dominos+=segment(i);
			
		}
		
		System.out.println(dominos);

	}

}
